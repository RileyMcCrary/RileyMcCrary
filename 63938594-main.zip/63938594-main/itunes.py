#This is a direct copy of something from the Python course that I took. It is intersting and should work but currently doesn't for some reason.
#It makes a request to an Apple URL and should pull information and also translate it into fifty listed songs from itunes.

import json
import requests
import sys

if len(sys.argv) != 2:
    sys.exit()

response = requests.get('https://itunes.apple.com/search??entity=song&limit=50&term=' + sys.argv[1])

o = response.json()
for result in o['results']:
    print(result['trackName'])
