def main():
    #ask for user's items