import emoji

emo = input('Input: ')
print('Output: ' + emoji.emojize(emo))