def main(enter):
    enter = lower(hyp(enter))
    if "forty two" in enter or "42" in enter:
        print("Yes")
    else:
        print("No")

#This will turn all letters lowercase so there's fewer checks
def lower(letters):
    letters = letters.lower()
    return letters

def hyp(em):
    em = em.replace("-", " ")
    return em


main(input("The meaning of it all is? "))